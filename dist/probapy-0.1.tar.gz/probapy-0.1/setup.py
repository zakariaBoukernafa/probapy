from setuptools import setup

setup(name='probapy',
      version='0.1',
      description='Gaussian and binomial distributions package',
      packages=['probapy'],
      author = 'zakaria boukernafa',
      author_email = 'zakaria0697@gmail.com',
      zip_safe=False)
